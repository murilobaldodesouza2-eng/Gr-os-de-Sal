/* ==================================================================
   GRÃOS DE SAL RESTAURANTE — SCRIPT.JS
   JavaScript puro (sem dependências), organizado por funcionalidade.
   ================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ----------------------------------------------------------------
     1. HEADER: muda de aparência ao rolar a página
     ---------------------------------------------------------------- */
  const header = document.getElementById('header');
  const backToTop = document.getElementById('backToTop');

  function handleScrollEffects() {
    const scrolled = window.scrollY > 40;
    header.classList.toggle('scrolled', scrolled);
    backToTop.classList.toggle('show', window.scrollY > 500);
  }
  handleScrollEffects();
  window.addEventListener('scroll', handleScrollEffects, { passive: true });

  /* Botão "voltar ao topo" */
  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ----------------------------------------------------------------
     2. MENU MOBILE (hambúrguer)
     ---------------------------------------------------------------- */
  const hamburger = document.getElementById('hamburger');
  const nav = document.getElementById('nav');

  function toggleMenu(forceClose) {
    const isOpen = document.body.classList.contains('nav-open');
    const shouldOpen = forceClose === true ? false : !isOpen;
    document.body.classList.toggle('nav-open', shouldOpen);
    hamburger.setAttribute('aria-expanded', String(shouldOpen));
    hamburger.setAttribute('aria-label', shouldOpen ? 'Fechar menu' : 'Abrir menu');
  }

  hamburger.addEventListener('click', () => toggleMenu());

  /* Fecha o menu mobile ao clicar em um link de navegação */
  nav.querySelectorAll('.nav__link').forEach(link => {
    link.addEventListener('click', () => toggleMenu(true));
  });

  /* ----------------------------------------------------------------
     3. ROLAGEM SUAVE + DESTAQUE DO ITEM DE MENU ATIVO
     ---------------------------------------------------------------- */
  const navLinks = Array.from(document.querySelectorAll('.nav__link'));
  const sections = navLinks
    .map(link => document.querySelector(link.getAttribute('href')))
    .filter(Boolean);

  function setActiveLink() {
    let currentId = sections[0] ? sections[0].id : '';
    const scrollPos = window.scrollY + window.innerHeight * 0.35;

    sections.forEach(section => {
      if (section.offsetTop <= scrollPos) {
        currentId = section.id;
      }
    });

    navLinks.forEach(link => {
      link.classList.toggle('active', link.getAttribute('href') === `#${currentId}`);
    });
  }
  setActiveLink();
  window.addEventListener('scroll', setActiveLink, { passive: true });

  /* ----------------------------------------------------------------
     4. ANIMAÇÕES AO APARECER NA TELA (Intersection Observer)
     ---------------------------------------------------------------- */
  const revealEls = document.querySelectorAll('.reveal');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealEls.forEach(el => revealObserver.observe(el));

  /* ----------------------------------------------------------------
     5. ABAS DO CARDÁPIO (menu-tabs)
     ---------------------------------------------------------------- */
  const menuTabs = document.querySelectorAll('.menu-tab');
  const menuPanels = document.querySelectorAll('.menu-panel');

  menuTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;

      menuTabs.forEach(t => {
        t.classList.toggle('active', t === tab);
        t.setAttribute('aria-selected', String(t === tab));
      });

      menuPanels.forEach(panel => {
        const isTarget = panel.id === `tab-${target}`;
        panel.classList.toggle('active', isTarget);
        panel.hidden = !isTarget;
      });
    });
  });

  /* ----------------------------------------------------------------
     6. GALERIA: LIGHTBOX / MODAL
     ---------------------------------------------------------------- */
  const galleryItems = Array.from(document.querySelectorAll('.gallery-item'));
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxCaption = document.getElementById('lightboxCaption');
  const lightboxClose = document.getElementById('lightboxClose');
  const lightboxPrev = document.getElementById('lightboxPrev');
  const lightboxNext = document.getElementById('lightboxNext');
  let currentImageIndex = 0;

  function openLightbox(index) {
    currentImageIndex = index;
    updateLightboxImage();
    lightbox.classList.add('open');
    lightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    lightbox.classList.remove('open');
    lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  function updateLightboxImage() {
    const item = galleryItems[currentImageIndex];
    const img = item.querySelector('img');
    lightboxImg.src = img.src.replace('w=800', 'w=1400');
    lightboxImg.alt = img.alt;
    lightboxCaption.textContent = `${item.dataset.category} — ${img.alt}`;
  }

  galleryItems.forEach((item, index) => {
    item.addEventListener('click', () => openLightbox(index));
  });

  lightboxClose.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) closeLightbox();
  });

  lightboxPrev.addEventListener('click', () => {
    currentImageIndex = (currentImageIndex - 1 + galleryItems.length) % galleryItems.length;
    updateLightboxImage();
  });
  lightboxNext.addEventListener('click', () => {
    currentImageIndex = (currentImageIndex + 1) % galleryItems.length;
    updateLightboxImage();
  });

  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') lightboxPrev.click();
    if (e.key === 'ArrowRight') lightboxNext.click();
  });

  /* ----------------------------------------------------------------
     7. CARROSSEL DE AVALIAÇÕES (autoplay + controles + dots)
     ---------------------------------------------------------------- */
  const track = document.getElementById('testimonialTrack');
  const slides = Array.from(track.children);
  const dotsWrap = document.getElementById('testimonialDots');
  const prevBtn = document.getElementById('testimonialPrev');
  const nextBtn = document.getElementById('testimonialNext');
  let currentSlide = 0;
  let autoplayTimer = null;

  /* Cria os indicadores (dots) dinamicamente — usa <button> para navegação por teclado */
  slides.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.setAttribute('aria-label', `Ir para o depoimento ${i + 1}`);
    if (i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goToSlide(i));
    dotsWrap.appendChild(dot);
  });
  const dots = Array.from(dotsWrap.children);

  function goToSlide(index) {
    currentSlide = (index + slides.length) % slides.length;
    track.style.transform = `translateX(-${currentSlide * 100}%)`;
    dots.forEach((dot, i) => dot.classList.toggle('active', i === currentSlide));
    restartAutoplay();
  }

  prevBtn.addEventListener('click', () => goToSlide(currentSlide - 1));
  nextBtn.addEventListener('click', () => goToSlide(currentSlide + 1));

  function startAutoplay() {
    autoplayTimer = setInterval(() => goToSlideSilent(currentSlide + 1), 6000);
  }
  function goToSlideSilent(index) {
    currentSlide = (index + slides.length) % slides.length;
    track.style.transform = `translateX(-${currentSlide * 100}%)`;
    dots.forEach((dot, i) => dot.classList.toggle('active', i === currentSlide));
  }
  function restartAutoplay() {
    clearInterval(autoplayTimer);
    startAutoplay();
  }
  if (slides.length > 1) startAutoplay();

  /* Também garante que o track tenha a largura correta para a transição funcionar */
  track.style.transition = 'transform .6s cubic-bezier(0.22, 1, 0.36, 1)';

  /* ----------------------------------------------------------------
     8. FAQ — ACCORDION
     ---------------------------------------------------------------- */
  const accordionItems = document.querySelectorAll('.accordion__item');

  accordionItems.forEach(item => {
    const trigger = item.querySelector('.accordion__trigger');
    const panel = item.querySelector('.accordion__panel');

    trigger.addEventListener('click', () => {
      const isOpen = trigger.getAttribute('aria-expanded') === 'true';

      /* Fecha todos os outros itens (comportamento de accordion único) */
      accordionItems.forEach(other => {
        const otherTrigger = other.querySelector('.accordion__trigger');
        const otherPanel = other.querySelector('.accordion__panel');
        otherTrigger.setAttribute('aria-expanded', 'false');
        otherPanel.style.maxHeight = null;
      });

      /* Abre o item clicado, caso estivesse fechado */
      if (!isOpen) {
        trigger.setAttribute('aria-expanded', 'true');
        panel.style.maxHeight = panel.scrollHeight + 'px';
      }
    });
  });

  /* Recalcula a altura do painel aberto ao redimensionar a tela ou girar o
     celular, evitando que o texto fique cortado (ex.: mudança de orientação). */
  window.addEventListener('resize', () => {
    const openTrigger = document.querySelector('.accordion__trigger[aria-expanded="true"]');
    if (openTrigger) {
      const openPanel = openTrigger.parentElement.querySelector('.accordion__panel');
      openPanel.style.maxHeight = openPanel.scrollHeight + 'px';
    }
  });

  /* ----------------------------------------------------------------
     9. VALIDAÇÃO DO FORMULÁRIO DE CONTATO
     ---------------------------------------------------------------- */
  const form = document.getElementById('contactForm');
  const formSuccess = document.getElementById('formSuccess');

  const fields = {
    name: { el: document.getElementById('name'), error: document.getElementById('error-name') },
    phone: { el: document.getElementById('phone'), error: document.getElementById('error-phone') },
    email: { el: document.getElementById('email'), error: document.getElementById('error-email') },
    message: { el: document.getElementById('message'), error: document.getElementById('error-message') },
  };

  function showError(field, message) {
    field.el.classList.add('invalid');
    field.error.textContent = message;
  }
  function clearError(field) {
    field.el.classList.remove('invalid');
    field.error.textContent = '';
  }

  function validateForm() {
    let isValid = true;

    /* Nome — obrigatório */
    if (fields.name.el.value.trim().length < 2) {
      showError(fields.name, 'Por favor, informe seu nome completo.');
      isValid = false;
    } else {
      clearError(fields.name);
    }

    /* Telefone — obrigatório, validação simples de formato brasileiro */
    const phoneDigits = fields.phone.el.value.replace(/\D/g, '');
    if (phoneDigits.length < 10) {
      showError(fields.phone, 'Informe um telefone válido com DDD.');
      isValid = false;
    } else {
      clearError(fields.phone);
    }

    /* E-mail — opcional, mas se preenchido precisa ser válido */
    const emailValue = fields.email.el.value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (emailValue !== '' && !emailPattern.test(emailValue)) {
      showError(fields.email, 'Informe um e-mail válido ou deixe em branco.');
      isValid = false;
    } else {
      clearError(fields.email);
    }

    /* Mensagem — obrigatória */
    if (fields.message.el.value.trim().length < 5) {
      showError(fields.message, 'Escreva uma mensagem um pouco mais detalhada.');
      isValid = false;
    } else {
      clearError(fields.message);
    }

    return isValid;
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    formSuccess.classList.remove('show');

    if (!validateForm()) return;

    /* O formulário não possui backend próprio: o envio real acontece
       pelo WhatsApp do restaurante, com a mensagem já preenchida. */
    handleSubmit();
  });

  /* Número de WhatsApp do restaurante, no formato internacional
     (sem espaços, traços ou símbolos): (51) 3561-2129 -> 555135612129 */
  const WHATSAPP_NUMBER = '555135612129';

  function handleSubmit() {
    const name = fields.name.el.value.trim();
    const phone = fields.phone.el.value.trim();
    const email = fields.email.el.value.trim();
    const message = fields.message.el.value.trim();

    /* Monta a mensagem no formato solicitado */
    const whatsappText =
      'Olá, Grãos de Sal Restaurante!\n\n' +
      `Nome: ${name}\n` +
      `Telefone: ${phone}\n` +
      `E-mail: ${email || 'Não informado'}\n\n` +
      'Mensagem:\n' +
      message;

    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(whatsappText)}`;

    /* Abre o WhatsApp em uma nova aba/janela (quando o navegador permitir) */
    window.open(whatsappUrl, '_blank', 'noopener');

    /* Mostra a confirmação de redirecionamento SOMENTE depois de abrir o WhatsApp */
    formSuccess.classList.add('show');
    form.reset();
    setTimeout(() => formSuccess.classList.remove('show'), 6000);
  }

  /* ----------------------------------------------------------------
     10. ANO ATUAL NO RODAPÉ
     ---------------------------------------------------------------- */
  document.getElementById('year').textContent = new Date().getFullYear();

});
