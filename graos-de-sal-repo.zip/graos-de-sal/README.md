# Grãos de Sal Restaurante

Site institucional do Grãos de Sal Restaurante — restaurante brasileiro/self-service em Estância Velha/RS.

## Estrutura do projeto

- `index.html` — estrutura e conteúdo do site
- `style.css` — estilos (cores, layout, responsividade, animações)
- `script.js` — interatividade (menu, cardápio, galeria, carrossel, FAQ, formulário)
- `images/` — imagens usadas no site

## Tecnologias

HTML5, CSS3 e JavaScript puro — sem frameworks ou dependências externas.

## Como usar

Basta abrir o `index.html` em um navegador, ou publicar a pasta em qualquer serviço de hospedagem estática (GitHub Pages, Netlify, Vercel etc.).
